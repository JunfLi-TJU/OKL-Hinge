catLog <- function(myString, logFile){
  # catLog 
  #            -  write the myString to logFile with the append pattern
  #
  # myString   -  the string
  # logFile    -  the name of input file
  
  # Date: May 24, 2016
  # Author: Chang Feng
  
  cat(myString, file=logFile, append=TRUE)
}
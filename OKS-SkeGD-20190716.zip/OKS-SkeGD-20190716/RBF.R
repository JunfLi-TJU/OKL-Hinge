RBF <-function(x, y=x, param.kernel = 1/p){
  # RBF    
  #           		- calculate the rbf of matrix x and y
  # x,y       		- tow matrix
  # param.kernel    - parameter gamma
  
  # Date: Tuesday 7th January 2014
  # Author: Lizhong Ding, Jiangang Wu
  
  n <- nrow(x)
  m <- nrow(y)
  p <- ncol(x)
  normx <- drop((x^2) %*% rep(1, p))
  normy <- drop((y^2) %*% rep(1, p))
  a <- x %*% t(y)
  a <- (-2 * a + normx) + outer(rep(1, n), normy, "*")
  exp( - a* param.kernel)
}

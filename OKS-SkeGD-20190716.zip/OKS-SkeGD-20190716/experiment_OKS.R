rm(list=ls())

path = "D:/experiment/Conference Paper/AAAI/AAAI 2023/code/OKS-SkeGD-20190716"
setwd(path)

path       <- paste0("../OKS-SkeGD-20190716/c_data")# Data path ###############change_path############
resultsDir <- paste0("../OKS-SkeGD-20190716/Results/") # result path ###############change_path############
figDir     <- paste0("../OKS-SkeGD-20190716/R_plot/") # figure path ###############change_path############

testNum    <- 6 #################### test number ################


library("R.matlab")
library("MASS")
source("RBF.r")
source("catLog.r")
source("createRandID.r")
source("SkeGD.r")
source("CSketch_d.r")
source("RandSM.r")
source("TruncateFunction1.r")

options  <-list( t_tick = 0,
                 eta_SkeGD = 0.01,        # stepsize in SkeGD
                 B_OKS_SkeGD = 400,       # B in SkeGD
                 cycle = 3000,            # Qx�������� in SkeGD
                 sb = 0.2*0.75*400,       # sb in SkeGD
                 sa = 0.75*400,           # sa in SkeGD
                 CS_d = 4,                # d in SkeGD
                 k = 0.1*400              # truncation k in SkeGD
)

Candit   <- 4
logIndex <- -(1+Candit)/2
Gas      <- 1/(2*Candit^2) 

ALGOS    <- c("SkeGD")
DATASETS <- c("ijcnn1_all")

DATASETS.selected <- c(1:length(DATASETS))
ITERATION         <- seq(1, 10) # the latter one is the ITERATION NUMBER

# output file
dir.create(resultsDir, recursive=TRUE, showWarnings=FALSE)

logFile <- paste0(resultsDir, "OKS-Test-OKS-Per@Log-", Sys.Date(), "-test_", testNum)
rdaFile <- paste0(resultsDir, "OKS-Test-OKS-Per@rda-", Sys.Date(), "-test_", testNum,".rda")


cat("Test for OKS_SkeGD: Online Kernel Selection via SkeGD.\n", logFile, append = F)	
catLog("ALGOS: OKS_SkeGD\n",logFile)
catLog("\nDatasets: ",logFile)
catLog(DATASETS,logFile)
catLog(sprintf("\n#Iteration = %d.\n", length(ITERATION)),logFile)
catLog("\n===================================================\n",logFile)
catLog(sprintf("Program started at %s.\n", date()),logFile)
catLog("===================================================\n\n\n",logFile)


Time    <- array(0, c(length(ITERATION), length(ALGOS)))
Loss    <- array(0, c(length(ITERATION), length(ALGOS)))
optGa   <- array(0, c(length(ITERATION), length(ALGOS)))

AvgOptGas <- array(0, c(length(ITERATION), length(ALGOS)))

res.OptGas <- list()
res.Loss   <- list()
res.Time   <- list()
res.index  <- list()
for (data.ind in DATASETS.selected) {
  
  catLog("\n-----------------------------------------------------\n",logFile)
  catLog(sprintf("Dataset: %s \n", DATASETS[data.ind]),logFile)
  catLog("Candidate Kernel Set i: ",logFile)
  catLog(sprintf("%f ", Candit), logFile)
  catLog("\n-----------------------------------------------------\n",logFile)

  trainingData <- paste0(DATASETS[data.ind], ".train") # e.g., splice.test and  splice.train
  trainingFile <- file.path(path, trainingData)
  trainingMatrix <- read.table(file = trainingFile)
  xTrain <- t(trainingMatrix[,-1])
  yTrain <- trainingMatrix[,1]
  
  X<- t(xTrain)
  Y<- c(yTrain)
  
  n<-nrow(X)
  
  options$t_tick <- floor(n/40) ################ 40 is the number of plot example #######
  m         <- floor(n/options$t_tick)+1
  
  
  AvgOptGas <- array(0, c(length(ALGOS), m))
  AvgLoss   <- array(0, c(length(ALGOS), m))
  AvgTime   <- array(0, c(length(ALGOS), m))
  
  catLog("\n===================================================\n",logFile)
#  catLog(sprintf("===================complete status==========================\n", testNum), logFile)
  
  for (iter in ITERATION) {
    id_list <- createRandID(n,1)
    
    ###### Our Method: SkeGD ########## 
    res_SkeGD <- SkeGD(Y, X, id_list, options, Gas) # booleta= TRUE: eta = 1/lambda t; booleta= FALSE: fixed stepsize  

    AvgOptGas[1, ] <-  AvgOptGas[1, ] + res_SkeGD$MidResult$optGas
    AvgLoss[1, ]   <-  AvgLoss[1, ] + res_SkeGD$MidResult$loss_v  
    AvgTime[1, ]   <-  AvgTime[1, ] + res_SkeGD$MidResult$TMs
    Time[iter, 1]  <-  res_SkeGD$run_time     #ÿ��iteration ������ʱ�� (һ����)
    Loss[iter, 1]  <-  res_SkeGD$loss_avg     #ÿ��iteration �Ĵ����� (һ����)
    
    catLog(sprintf("\n OKS_SkeGD: iter= %d complete\n", iter),logFile) # Record the complete status
  }
  AvgOptGas <- AvgOptGas/length(ITERATION)
  AvgLoss   <- AvgLoss/length(ITERATION)
  AvgTime   <- AvgTime/length(ITERATION)
  
  index       <- res_SkeGD$MidResult$mistakes_idx
  LogSigmas   <- (-(1+log2(AvgOptGas))/2)
  
  res.OptGas[[data.ind]] <- LogSigmas
  res.Loss[[data.ind]]   <- AvgLoss
  res.Time[[data.ind]]   <- AvgTime
  res.index[[data.ind]]  <- index

  save(ALGOS, DATASETS, logIndex, res.OptGas, res.Loss,  res.Time, res.index, file = rdaFile)
  
  catLog("\n===================================================\n",logFile)
  catLog(sprintf("===================test_%d==========================\n", testNum), logFile)
  catLog(sprintf("Algorithm & Mistake Rates& cpu running time\\\\\n"),logFile)
  catLog(sprintf("%s   &%.3f \t$\\pm$ %.3f \t& %.3f \t \\\\\n", ALGOS[1], mean(Loss[ ,1])*100, 
                 sd(as.vector(Loss[ ,1]))*100, mean(Time[ ,1])),logFile)
  catLog("\n===================================================\n\n\n\n\n\n\n",logFile)
}

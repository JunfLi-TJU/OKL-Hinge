#CSketch_d()    Compute the Count-Sketch matrix
CSketch_d <- function(B,s,d){  
  
  CountSke <- matrix(0,B,s)
  if(s%%d==0)
  {
    indexHASH <- matrix(sample(1:s/d,d*B,replace=TRUE),d,B)
    bitHash   <- matrix((sample(1:2,d*B,replace=TRUE)-1.5)*2,d,B)
    
    for(i in 1:B)
    {
      for(j in 1:d)
      {
        CountSke[i,s/d*(j-1)+indexHASH[j,i]]  <- bitHash[j,i]
      }
    }
  }
  else{
    
    indexHASH <- matrix(sample(1:floor(s/d),d*B,replace=TRUE),d,B)
    bitHash   <- matrix((sample(1:2,d*B,replace=TRUE)-1.5)*2,d,B)
    
    for(i in 1:B)
    {
      indexHASH[d,i]  <- sample(s-(d-1)*floor(s/d),1)
    }
    
    for(i in 1:B)
    {
      for(j in 1:d)
      {
        CountSke[i,floor(s/d)*(j-1)+indexHASH[j,i]]  <- bitHash[j,i]
      }
    }
  }
  
  list(CountSke=1/sqrt(d)*CountSke)
}
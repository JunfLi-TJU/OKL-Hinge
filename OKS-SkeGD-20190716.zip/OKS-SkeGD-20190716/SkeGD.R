#SkeGD  use List to realize 
SkeGD <- function(Y, X, id_list, options, Gas){
  ID     <- id_list 
  N      <- nrow(X) 
  d      <- ncol(X)
  
  Gas    <- Gas
  
  eta_SkeGD <- options$eta_SkeGD
  eta_SkeGD <- 0.1/sqrt(N)
  B         <- options$B_OKS_SkeGD
  cycle     <- options$cycle    #Qx��������
  cycle     <- 0.3*N
  t_tick    <- data.frame(options)$t_tick 
  sb        <- options$sb
  sa        <- options$sa
  CS_d      <- options$CS_d
  k         <- options$k
  
  
  alpha  <- list()    #��forѭ�� ��ʼ��alpha ��SV���ȸ�ֵΪ�� ��������|Gas|��
  SV     <- list()
  w      <- list()    #��������
  Qx     <- list()
  Sb     <- list()
  Sa     <- list()
  SVb    <- list()
  Ca     <- list()
  Cb     <- list()
  S      <- list()
  M      <- list()
  SVb_location <- list()
  
  flag   <- 0
  y_hat  <- 0  #Ԥ�����
  T0     <- 0
  
  length(Gas) <- 1
  
  for (i in 1:length(Gas)) {
    
    alpha <- c(alpha, list(NULL))
    SV    <- c(SV, list(NULL))
    w     <- c(w, list(NULL))
    Qx    <- c(Qx, list(NULL))
    Sb    <- c(Sb, list(NULL))
    Sa    <- c(Sa, list(NULL))
    SVb   <- c(SVb, list(NULL))
    Ca    <- c(Ca, list(NULL))
    Cb    <- c(Cb, list(NULL))
    SVb_location <- c(SVb_location, list(NULL))
    S    <- c(S, list(NULL))
    M    <- c(M, list(NULL))
  }
  
  error        <- 0
  mistakes_idx <- NULL
  TMs          <- NULL
  loss_v       <- NULL
  optGas       <- NULL
  
  t1=proc.time()[3]
  
  for(i in 1:length(Gas))#����length(Gas)�� Sa  Count-Sketch matrix
  {
    res_countsketch <- CSketch_d(B,sa,CS_d)
    Sa[[i]]         <-res_countsketch$CountSke
  }
  
  for (t in 1:length(ID)){
    id   <- ID[t] 
    x_t  <- X[id, , drop=FALSE]#1*d 
    y_t  <- Y[id] 
    
    #################################
    #Use SkeGD to update the hypothesis begin!!
    ################################### 
    kb   <-1  ####  ��ʼ����kb=1�Ƿ�������ж��Ƿ�Ϊ0   ��Ӱ�����
    for(index in 1:length(Gas))
    {
      if(length(alpha[[index]])==0)
      {
        f_t=0
      }
      else{
        
        if(flag==0)#SVδ��
        {
          k_t  <- RBF(x_t, X[SV[[index]], ,drop=FALSE], Gas)
          f_t  <- alpha[[index]]%*%t(k_t)
        }
        else{
          kb    <- RBF(x_t, X[SVb[[index]], ,drop=FALSE], Gas)
          phi_t <- kb%*%Qx[[index]]
          
          f_t   <- w[[index]]%*%t(phi_t)
        }
        
      }
      
      y_hat  <- f_t
      
      if(y_t*y_hat<1)
      {
        
        T0=T0+1
        #         if(sum(kb)>1e-10)     ##############################kb==0ʱģ�Ͳ����и���
        #         {
        if(length(alpha[[index]])<B)     #�ռ�B����׶�
        {
          alpha[[index]]  <- c(alpha[[index]],eta_SkeGD*y_t)
          SV[[index]]     <- c(SV[[index]], id)
          
        }
        else{                   
          if(flag==0)  #�մﵽB����  ���г�ʼ��
          {
            psi  <- RBF(x_t, X[SV[[index]], ,drop=FALSE],  Gas)  #1*SV������
            
            K_B = RBF(X[SV[[index]], ,drop=FALSE], X[SV[[index]], ,drop=FALSE], Gas)
            RandSM_res    <- RandSM(K_B,SV[[index]],B,sb)  #������������
            Sb[[index]]            <- RandSM_res$Sb
            Cb[[index]]            <- RandSM_res$Cb
            SVb[[index]]           <- RandSM_res$SVb
            SVb_location[[index]]  <- RandSM_res$SVb_location
            
            kb  <- psi[SVb_location[[index]]]
            if(sum(kb)>1e-8)
            {
              Ca[[index]]  <- K_B%*%Sa[[index]]    ###count-sketch �������
              S[[index]]   <- t(Sa[[index]])%*%Ca[[index]]   #phi_pp  sa*sa  sa ��������sp��Ӧ  sb������sm��Ӧ
              M[[index]]   <- t(Sa[[index]])%*%Cb[[index]]   #phi_pm  sa*sb
              
              ##�������� M<-Sa'*Cb
              ##
              # psi  <- RBF(x_t, X[SV[[index]], ,drop=FALSE],  Gas)  #1*SV������
              ske_t <- CSketch_d(1,sa,CS_d)$CountSke  # 1*sa �ľ���
              
              Rab   <- t(ske_t)%*%(psi%*%Sb[[index]])
              
              M[[index]] <- M[[index]]+Rab
              
              ##��������S<-Sa'*Ca
              Raa  <- t(ske_t)%*%(psi%*%Sa[[index]])
              xi   <- 1
              Taa  <- xi*t(ske_t)%*%ske_t
              S[[index]]  <- S[[index]]+Raa+t(Raa)+Taa
              
              ##����Qx
              # kb  <- psi[SVb_location[[index]]]
              
              SVD_result  <- svd(S[[index]])    ##��һ���ضϲ���
              V           <- SVD_result$u
              Sigma       <- diag(SVD_result$d)
              Qx[[index]]    <- ginv(M[[index]])%*%V%*%Sigma^(0.5)
              phi_t          <- kb%*%Qx[[index]]   # 1*sb��
              
              
              ##��ʼ��w   w��1*sb������
              
              w[[index]]  <- alpha[[index]]%*%t(psi)%*%(phi_t/norm(phi_t,"2")^2)
              w[[index]]  <- w[[index]] + eta_SkeGD*y_t*phi_t
              
              SV[[index]] <- c(SV[[index]],id)
              Sa[[index]] <- rbind(Sa[[index]],ske_t)
              
              flag <-1
            }
          }
          else{
            
            #���ڸ���Qx
            if(T0%%cycle==1)
            {
              if(sum(kb)>1e-8)
              {
                ##�������� M<-Sa'*Cb
                psi   <- RBF(x_t, X[SV[[index]], ,drop=FALSE],  Gas)  #1*SV������
                ske_t <- CSketch_d(1,sa,CS_d)$CountSke
                
                Rab   <- t(ske_t)%*%kb
                M[[index]] <- M[[index]]+Rab
                
                ##��������S<-Sa'*Ca
                Raa   <- t(ske_t)%*%(psi%*%Sa[[index]])
                xi    <- 1
                Taa   <- xi*t(ske_t)%*%ske_t
                S[[index]]  <- S[[index]]+Raa+t(Raa)+Taa
                
                ##����Qx
                SVD_result     <- svd(S[[index]])    ##�ضϲ���
                SVD_T_result   <- Truncation1(SVD_result$u,SVD_result$d,SVD_result$v,k)
                V              <- SVD_T_result$uu
                Sigma          <- diag(SVD_T_result$ss)
                Qx[[index]]    <- ginv(M[[index]])%*%V%*%Sigma^(0.5)
                phi_t          <- kb%*%Qx[[index]]   # 1*sb��
                
                w[[index]]  <- f_t%*%(phi_t/norm(phi_t,"2")^2)
                
                SV[[index]] <- c(SV[[index]],id)
                Sa[[index]] <- rbind(Sa[[index]],ske_t)
              }
            }
            w[[index]] <- w[[index]]+eta_SkeGD*y_t*phi_t
          }
    
        }
      }
      
    }
    if(y_t*y_hat <=0){ 
      error <- error+1
    }
    
    if (t%%t_tick==0||t==1){
      run_time     <- (proc.time()-t1)[3]
      mistakes_idx <- c(mistakes_idx, t) 
      TMs          <- c(TMs, run_time) 
      loss_v       <- c(loss_v, error/t) 
      optGas       <- c(optGas, Gas)
    }
  }
  run_time     <- (proc.time()-t1)[3]
  loss_avg     <- error/N 
  MidResult    <- list(mistakes_idx=mistakes_idx, TMs = TMs,  loss_v =loss_v, optGas =optGas)
  
  list(Gas = Gas, run_time = run_time, loss_avg = loss_avg,  MidResult = MidResult)
}

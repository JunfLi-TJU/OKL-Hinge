createRandID <- function(n, t){
#generate random permutation of training instances
# n - dataset size
# t - number of trials, usually set to 20
ID<-matrix(rep(0,n*t),t)
for (i in 1:t)
    {ID[i,] <- sample(n)}
ID
}
